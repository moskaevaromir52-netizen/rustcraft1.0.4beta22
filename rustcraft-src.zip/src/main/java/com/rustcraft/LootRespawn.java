package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Возрождение ящиков и бочек монументов, как в Rust: через некоторое время после опустошения. */
public class LootRespawn extends SavedData {
    private static final double PLAYER_BLOCK_RADIUS = 24.0;

    private static class Entry {
        final long pos;
        final String block;
        final long at;

        Entry(long pos, String block, long at) {
            this.pos = pos;
            this.block = block;
            this.at = at;
        }
    }

    private final List<Entry> entries = new ArrayList<>();

    public static LootRespawn get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(LootRespawn::load, LootRespawn::new, "rustcraft_respawn");
    }

    private static LootRespawn load(CompoundTag tag) {
        LootRespawn d = new LootRespawn();
        ListTag l = tag.getList("e", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            d.entries.add(new Entry(c.getLong("p"), c.getString("b"), c.getLong("t")));
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Entry e : entries) {
            CompoundTag c = new CompoundTag();
            c.putLong("p", e.pos);
            c.putString("b", e.block);
            c.putLong("t", e.at);
            l.add(c);
        }
        tag.put("e", l);
        return tag;
    }

    /** Возродить блок в этой позиции через delayTicks тиков (считается по игровому времени уровня). */
    public void schedule(ServerLevel level, BlockPos pos, Block block, int delayTicks) {
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(block);
        if (key == null) return;
        entries.add(new Entry(pos.asLong(), key.toString(), level.getGameTime() + delayTicks));
        setDirty();
    }

    /** Вызывается раз в ~5 секунд. */
    public void tick(ServerLevel level) {
        long now = level.getGameTime();
        boolean changed = false;

        for (Iterator<Entry> it = entries.iterator(); it.hasNext(); ) {
            Entry e = it.next();
            if (now < e.at) continue;
            BlockPos pos = BlockPos.of(e.pos);
            if (!level.isLoaded(pos)) continue;
            Player near = level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    PLAYER_BLOCK_RADIUS, false);
            if (near != null) continue;
            Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(e.block));
            if (block != null) {
                BlockState cur = level.getBlockState(pos);
                if (cur.isAir() || cur.canBeReplaced()) {
                    BlockState st = block.defaultBlockState();
                    if (block instanceof BarrelBlock) st = st.setValue(BarrelBlock.RESPAWN, true);
                    level.setBlock(pos, st, 3);
                }
            }
            it.remove();
            changed = true;
        }
        if (changed) setDirty();
    }
}
