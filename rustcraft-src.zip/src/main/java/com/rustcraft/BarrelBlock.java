package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Жёлтая бочка. Не ломается как обычный блок: по ней нужно бить (ЛКМ, каждый клик - удар),
 * она разрушается постепенно и роняет скрап. По бочке можно стрелять.
 */
public class BarrelBlock extends Block {
    public static final IntegerProperty HITS = IntegerProperty.create("hits", 0, RustBalance.BARREL_HP - 1);
    /** true у бочек монументов: они возрождаются после разрушения. */
    public static final BooleanProperty RESPAWN = BooleanProperty.create("respawn");
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 16, 14);

    public BarrelBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(HITS, 0).setValue(RESPAWN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(HITS, RESPAWN);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    /** Вызывается сервером в начале каждого клика ЛКМ по блоку. */
    @Override
    @SuppressWarnings("deprecation")
    public void attack(BlockState state, Level level, BlockPos pos, Player player) {
        if (!(level instanceof ServerLevel sl)) return;
        CompoundTag d = player.getPersistentData();
        long now = sl.getGameTime();
        if (now - d.getLong("rust_barrel_hit") < RustBalance.BARREL_HIT_DELAY) return;
        d.putLong("rust_barrel_hit", now);
        hit(sl, pos, state, power(player));
    }

    private static int power(Player p) {
        Item it = p.getMainHandItem().getItem();
        if (it instanceof AxeItem || it instanceof PickaxeItem) return 3;
        if (it instanceof SwordItem) return 2;
        return 1;
    }

    public static void hit(ServerLevel level, BlockPos pos, BlockState state, int power) {
        int hits = state.getValue(HITS) + power;
        if (hits >= RustBalance.BARREL_HP) {
            breakBarrel(level, pos, state);
            return;
        }
        level.setBlock(pos, state.setValue(HITS, hits), 3);
        level.playSound(null, pos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 1.0F, 0.7F);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
                pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 6, 0.25, 0.3, 0.25, 0.05);
    }

    private static void breakBarrel(ServerLevel level, BlockPos pos, BlockState state) {
        RandomSource r = level.random;
        int scrap = RustBalance.BARREL_SCRAP_MIN
                + r.nextInt(RustBalance.BARREL_SCRAP_MAX - RustBalance.BARREL_SCRAP_MIN + 1);
        Block.popResource(level, pos, new ItemStack(ModItems.SCRAP.get(), scrap));
        if (r.nextFloat() < 0.35F) {
            Block.popResource(level, pos, new ItemStack(ModItems.get("metal_fragments"), 2 + r.nextInt(5)));
        }
        if (r.nextFloat() < 0.12F) {
            Block.popResource(level, pos, new ItemStack(ModItems.get("metal_pipe")));
        }
        if (r.nextFloat() < 0.06F) {
            Block.popResource(level, pos, new ItemStack(ModItems.get("gears")));
        }
        if (r.nextFloat() < 0.03F) {
            Block.popResource(level, pos, new ItemStack(ModItems.get("metal_spring")));
        }
        level.destroyBlock(pos, false);
        if (state.getValue(RESPAWN)) {
            LootRespawn.get(level).schedule(level, pos, ModBlocks.BARREL.get(), RustBalance.BARREL_RESPAWN_TICKS);
        }
    }
}
