package com.rustcraft;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraftforge.registries.ForgeRegistries;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Монументы (заправка, супермаркет, склад, маяк, военный пост, свалка).
 * Чертежи лежат в assets/rustcraft/monuments/*.json и ставятся в центр чанка со случайным поворотом.
 * Ящики и бочки получают лут и респавн.
 */
public class MonumentFeature extends Feature<MonumentFeature.Config> {

    public record Config(String name, boolean water) implements FeatureConfiguration {
        public static final Codec<Config> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("name").forGetter(Config::name),
                Codec.BOOL.optionalFieldOf("water", false).forGetter(Config::water)).apply(i, Config::new));
    }

    private static final class Blueprint {
        int height;
        int minx, maxx, minz, maxz;
        final List<JsonObject> pal = new ArrayList<>();
        final List<int[]> voxels = new ArrayList<>();
        final List<BlockState> states = new ArrayList<>();
        final List<String> special = new ArrayList<>();
    }

    private static final Map<String, Blueprint> CACHE = new ConcurrentHashMap<>();
    private static final Gson GSON = new Gson();

    public MonumentFeature() {
        super(Config.CODEC);
    }

    private static Blueprint load(String name) {
        return CACHE.computeIfAbsent(name, n -> {
            try (InputStream in = MonumentFeature.class.getResourceAsStream("/assets/" + RustCraft.MODID + "/monuments/" + n + ".json")) {
                if (in == null) return null;
                JsonObject o = GSON.fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), JsonObject.class);
                Blueprint b = new Blueprint();
                b.height = o.get("height").getAsInt();
                b.minx = o.get("minx").getAsInt();
                b.maxx = o.get("maxx").getAsInt();
                b.minz = o.get("minz").getAsInt();
                b.maxz = o.get("maxz").getAsInt();
                for (JsonElement pe : o.getAsJsonArray("pal")) {
                    JsonObject p = pe.getAsJsonObject();
                    String id = p.get("b").getAsString();
                    if (id.startsWith("SPECIAL:")) {
                        b.states.add(null);
                        b.special.add(id.substring(8));
                    } else {
                        Block blk = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(id));
                        BlockState st = blk == null ? Blocks.AIR.defaultBlockState() : blk.defaultBlockState();
                        JsonObject props = p.getAsJsonObject("p");
                        if (props != null) {
                            for (Map.Entry<String, JsonElement> e : props.entrySet()) {
                                Property<?> prop = st.getBlock().getStateDefinition().getProperty(e.getKey());
                                if (prop != null) st = withValue(st, prop, e.getValue().getAsString());
                            }
                        }
                        b.states.add(st);
                        b.special.add(null);
                    }
                }
                for (JsonElement ve : o.getAsJsonArray("v")) {
                    JsonArray a = ve.getAsJsonArray();
                    b.voxels.add(new int[]{a.get(0).getAsInt(), a.get(1).getAsInt(), a.get(2).getAsInt(), a.get(3).getAsInt()});
                }
                return b;
            } catch (Exception ex) {
                return null;
            }
        });
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState s, Property<T> prop, String v) {
        Optional<T> o = prop.getValue(v);
        return o.isPresent() ? s.setValue(prop, o.get()) : s;
    }

    private static BlockState specialState(String id) {
        if ("barrel".equals(id)) {
            return ModBlocks.BARREL.get().defaultBlockState().setValue(BarrelBlock.RESPAWN, true);
        }
        Block b = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(RustCraft.MODID, id));
        return b == null ? Blocks.AIR.defaultBlockState() : b.defaultBlockState();
    }

    @Override
    public boolean place(FeaturePlaceContext<Config> ctx) {
        BlockPos o = ctx.origin();
        int cx = (o.getX() >> 4 << 4) + 8;
        int cz = (o.getZ() >> 4 << 4) + 8;
        return build(ctx.level(), ctx.config().name(), cx, cz, Rotation.getRandom(ctx.random()), ctx.config().water());
    }

    /** Поворот, при котором «передняя» сторона чертежа (+z) смотрит в сторону (fx, fz). */
    public static Rotation facing(double fx, double fz) {
        Rotation best = Rotation.NONE;
        double bestDot = -1e9;
        // повёрнутый вектор +z для каждого поворота
        Rotation[] rots = {Rotation.NONE, Rotation.CLOCKWISE_90, Rotation.CLOCKWISE_180, Rotation.COUNTERCLOCKWISE_90};
        int[][] dirs = {{0, 1}, {-1, 0}, {0, -1}, {1, 0}};
        for (int i = 0; i < 4; i++) {
            double d = dirs[i][0] * fx + dirs[i][1] * fz;
            if (d > bestDot) {
                bestDot = d;
                best = rots[i];
            }
        }
        return best;
    }

    /** Ставит чертёж с центром (cx, cz). water=true - стоит в воде (озеро, море). */
    public static boolean build(WorldGenLevel level, String name, int cx, int cz, Rotation rot, boolean water) {
        Blueprint bp = load(name);
        if (bp == null) return false;
        int ex = Math.max(Math.abs(bp.minx), Math.abs(bp.maxx));
        int ez = Math.max(Math.abs(bp.minz), Math.abs(bp.maxz));
        int half = Math.min(7, Math.max(ex, ez));

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int minFloor = Integer.MAX_VALUE;
        int maxFloor = Integer.MIN_VALUE;
        int[] xs = {-half, 0, half};
        for (int dx : xs) {
            for (int dz : xs) {
                int x = cx + dx;
                int z = cz + dz;
                int h = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
                BlockState below = level.getBlockState(new BlockPos(x, h - 1, z));
                boolean wet = !below.getFluidState().isEmpty();
                if (water) {
                    int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
                    int depth = h - floor;
                    // озеро или море: везде вода, глубина от 1 до 12
                    if (!wet || depth < 1 || depth > 12) return false;
                    minFloor = Math.min(minFloor, floor);
                    maxFloor = Math.max(maxFloor, floor);
                } else if (wet) {
                    return false;
                }
                min = Math.min(min, h);
                max = Math.max(max, h);
            }
        }
        if (water ? (maxFloor - minFloor > 6 || max - min > 1) : (max - min > 4)) return false;
        int baseY = max;
        if (baseY + bp.height + 2 >= level.getMaxBuildHeight() || baseY < level.getMinBuildHeight() + 5) return false;

        // фундамент (на суше - под неровностями, в воде - сваи до дна) и очистка пространства над площадкой
        BlockState fill = Blocks.COBBLESTONE.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                int x = cx + dx;
                int z = cz + dz;
                int from = water ? level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z)
                        : level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
                for (int y = from; y < baseY; y++) level.setBlock(new BlockPos(x, y, z), fill, 2);
                for (int y = baseY; y < baseY + bp.height + 1; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!level.getBlockState(p).isAir()) level.setBlock(p, air, 2);
                }
            }
        }

        for (int[] v : bp.voxels) {
            int lx = v[0];
            int lz = v[2];
            int rx;
            int rz;
            switch (rot) {
                case CLOCKWISE_90 -> {
                    rx = -lz;
                    rz = lx;
                }
                case CLOCKWISE_180 -> {
                    rx = -lx;
                    rz = -lz;
                }
                case COUNTERCLOCKWISE_90 -> {
                    rx = lz;
                    rz = -lx;
                }
                default -> {
                    rx = lx;
                    rz = lz;
                }
            }
            BlockPos pos = new BlockPos(cx + rx, baseY + v[1], cz + rz);
            BlockState st = bp.states.get(v[3]);
            if (st == null) st = specialState(bp.special.get(v[3]));
            else st = st.rotate(rot);
            level.setBlock(pos, st, 2);
        }
        return true;
    }
}
