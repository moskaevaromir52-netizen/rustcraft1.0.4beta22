package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Содержимое ящика. Лут берётся из лут-таблицы ящика при первом открытии. */
public class CrateBlockEntity extends RandomizableContainerBlockEntity {
    private NonNullList<ItemStack> items;
    private final CrateBlock.Type type;

    public CrateBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CRATE.get(), pos, state);
        this.type = state.getBlock() instanceof CrateBlock cb ? cb.type : CrateBlock.Type.NORMAL;
        this.items = NonNullList.withSize(type.rows * 9, ItemStack.EMPTY);
        this.lootTable = type.lootTable();
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable(getBlockState().getBlock().getDescriptionId());
    }

    @Override
    public int getContainerSize() {
        return type.rows * 9;
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return items;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> list) {
        items = list;
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory inv) {
        return new ChestMenu(type.rows == 3 ? MenuType.GENERIC_9x3 : MenuType.GENERIC_9x2, id, inv, this, type.rows);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        // ящик, который уже открывали, не должен снова получить лут из таблицы
        this.lootTable = null;
        if (!tryLoadLootTable(tag)) {
            ContainerHelper.loadAllItems(tag, this.items);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (!trySaveLootTable(tag)) {
            ContainerHelper.saveAllItems(tag, this.items);
        }
    }

    /** Закрыли пустой ящик - он исчезает и возродится позже. */
    @Override
    public void stopOpen(Player player) {
        if (level instanceof ServerLevel sl && this.isEmpty()) {
            BlockPos pos = worldPosition;
            net.minecraft.world.level.block.Block block = getBlockState().getBlock();
            sl.playSound(null, pos, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 0.8F, 0.9F);
            sl.removeBlock(pos, false);
            LootRespawn.get(sl).schedule(sl, pos, block, type.respawn);
        }
    }
}
