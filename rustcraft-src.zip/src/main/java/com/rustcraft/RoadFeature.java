package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Каждый чанк рисует свою часть дорожной сети (RustRoads): асфальт с жёлтой разметкой,
 * мосты через воду, ящики на обочине и монументы у дорог.
 */
public class RoadFeature extends Feature<NoneFeatureConfiguration> {
    private static final BlockState ASPHALT = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState LINE = Blocks.YELLOW_CONCRETE.defaultBlockState();

    public RoadFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        ServerLevel sl = level.getLevel();
        if (sl.dimension() != Level.OVERWORLD) return false;
        int chunkX = ctx.origin().getX() >> 4;
        int chunkZ = ctx.origin().getZ() >> 4;
        int x0 = chunkX * 16;
        int z0 = chunkZ * 16;
        long seed = level.getSeed();
        RustRoads.Plan plan = RustRoads.plan(sl, seed, chunkX, chunkZ);
        if (plan.paint.isEmpty() && plan.monuments.isEmpty() && plan.crates.isEmpty()) return false;

        // монументы у дорог: вход смотрит на дорогу
        for (RustRoads.Mon m : plan.monuments) {
            MonumentFeature.build(level, m.type(), m.x(), m.z(), MonumentFeature.facing(m.fx(), m.fz()), false);
        }

        // асфальт
        for (RustRoads.Road r : plan.paint) {
            double len = r.len();
            int steps = (int) Math.ceil(len * r.tEnd() * 2.0);
            for (int i = 0; i <= steps; i++) {
                double t = Math.min(r.tEnd(), i / (2.0 * len));
                double px = r.x(t);
                double pz = r.z(t);
                if (px < x0 - 4 || px > x0 + 19 || pz < z0 - 4 || pz > z0 + 19) continue;
                int bx = (int) Math.floor(px);
                int bz = (int) Math.floor(pz);
                for (int dx = -3; dx <= 3; dx++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        int x = bx + dx;
                        int z = bz + dz;
                        if (x < x0 || x > x0 + 15 || z < z0 || z > z0 + 15) continue;
                        double d = Math.hypot(x + 0.5 - px, z + 0.5 - pz);
                        if (d <= RustRoads.ROAD_RADIUS) paint(level, x, z, ASPHALT);
                    }
                }
            }
            // пунктирная разметка по центру
            for (int i = 0; i <= steps; i++) {
                if ((i / 8) % 2 != 0) continue;
                double t = Math.min(r.tEnd(), i / (2.0 * len));
                int x = (int) Math.floor(r.x(t));
                int z = (int) Math.floor(r.z(t));
                if (x < x0 || x > x0 + 15 || z < z0 || z > z0 + 15) continue;
                paint(level, x, z, LINE);
            }
        }

        // обычные ящики на обочине
        for (RustRoads.Crate c : plan.crates) {
            int h = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, c.x(), c.z());
            BlockPos pos = new BlockPos(c.x(), h, c.z());
            BlockState below = level.getBlockState(pos.below());
            if (below.getFluidState().isEmpty() && !below.isAir() && level.getBlockState(pos).isAir()
                    && !below.is(ASPHALT.getBlock()) && !below.is(LINE.getBlock())) {
                level.setBlock(pos, ModBlocks.NORMAL_CRATE.get().defaultBlockState(), 2);
            }
        }
        return true;
    }

    /** Асфальт на поверхность земли; над водой - мост на уровне воды. */
    private static void paint(WorldGenLevel level, int x, int z, BlockState state) {
        int h = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos below = new BlockPos(x, h - 1, z);
        if (!level.getBlockState(below).getFluidState().isEmpty()) {
            level.setBlock(new BlockPos(x, h, z), state, 2);
        } else {
            level.setBlock(below, state, 2);
        }
    }
}
