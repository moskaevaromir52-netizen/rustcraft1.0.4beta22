package com.rustcraft;

/**
 * Прочность элементов построек (как в Rust): дерево 250, камень 500, металл 1000, бронированный 2000.
 * Индекс 4 - «хворост» (twig): самая первая стадия, 10 HP, ломается чем угодно.
 */
public final class StructureHealth {
    public static final int TWIG = 4;
    public static final float[] HP = {250.0F, 500.0F, 1000.0F, 2000.0F, 10.0F};
    /** Через сколько тиков после урона можно чинить (30 секунд, как в Rust). */
    public static final int REPAIR_DELAY = 600;
    /** Окно сноса элемента владельцем после постройки (10 минут, как в Rust). */
    public static final int DEMOLISH_WINDOW = 12000;
    public static final int MELEE_DELAY = 8;

    private StructureHealth() {
    }

    public static float max(int tier) {
        return HP[Math.max(0, Math.min(HP.length - 1, tier))];
    }

    /** Порядок прочности: хворост ниже дерева. */
    public static int rank(int tier) {
        return tier == TWIG ? -1 : tier;
    }
}
