package com.rustcraft;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class RustNet {
    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RustCraft.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private RustNet() {
    }

    public static void init() {
        CHANNEL.registerMessage(0, AttachPacket.class, AttachPacket::encode, AttachPacket::decode, AttachPacket::handle);
        CHANNEL.registerMessage(1, FirePacket.class, FirePacket::encode, FirePacket::decode, FirePacket::handle);
    }
}
