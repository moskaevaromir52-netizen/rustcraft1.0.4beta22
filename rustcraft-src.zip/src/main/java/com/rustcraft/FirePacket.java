package com.rustcraft;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: игрок жмёт ЛКМ с оружием (aiming = держит ПКМ). */
public class FirePacket {
    private final boolean aiming;

    public FirePacket(boolean aiming) {
        this.aiming = aiming;
    }

    public static void encode(FirePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.aiming);
    }

    public static FirePacket decode(FriendlyByteBuf buf) {
        return new FirePacket(buf.readBoolean());
    }

    public static void handle(FirePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p == null) return;
            ItemStack stack = p.getMainHandItem();
            if (stack.getItem() instanceof GunItem gun && p.level() instanceof ServerLevel sl) {
                gun.fire(sl, p, stack, m.aiming);
            }
        });
        c.setPacketHandled(true);
    }
}
