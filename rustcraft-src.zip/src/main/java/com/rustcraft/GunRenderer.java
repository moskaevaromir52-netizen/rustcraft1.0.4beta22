package com.rustcraft;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Рисует оружие: в инвентаре/на земле - плоская иконка, в руках - 3D-модель
 * плюс 3D-модели установленных обвесов (под конкретное оружие).
 */
public class GunRenderer extends BlockEntityWithoutLevelRenderer {
    private static GunRenderer INSTANCE;

    public static GunRenderer instance() {
        if (INSTANCE == null) {
            Minecraft mc = Minecraft.getInstance();
            INSTANCE = new GunRenderer(mc);
        }
        return INSTANCE;
    }

    private GunRenderer(Minecraft mc) {
        super(mc.getBlockEntityRenderDispatcher(), mc.getEntityModels());
    }

    public static ResourceLocation model(String path) {
        return new ResourceLocation(RustCraft.MODID, "item/gun/" + path);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf,
                             int light, int overlay) {
        Minecraft mc = Minecraft.getInstance();
        ItemRenderer ir = mc.getItemRenderer();
        String id = Attachments.gunId(stack.getItem());

        ps.pushPose();
        ps.translate(0.5F, 0.5F, 0.5F);   // компенсируем сдвиг, который уже сделал внешний render()
        boolean flat = ctx == ItemDisplayContext.GUI || ctx == ItemDisplayContext.GROUND
                || ctx == ItemDisplayContext.FIXED;
        if (flat) {
            draw(ir, stack, ctx, ps, buf, light, overlay, model(id + "_icon"));
        } else {
            boolean fp = ctx.firstPerson();
            boolean tp = ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND
                    || ctx == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
            if (fp || tp) {
                draw(ir, stack, ctx, ps, buf, light, overlay, model(id + (fp ? "_fp" : "_tp")));
                for (Attachment.Slot s : Attachment.Slot.values()) {
                    Attachment a = Attachments.get(stack, s);
                    if (a != null) draw(ir, stack, ctx, ps, buf, light, overlay, model("att/" + id + "_" + a.id));
                }
            } else {
                draw(ir, stack, ctx, ps, buf, light, overlay, model(id + "_tp"));
            }
        }
        ps.popPose();
    }

    private static void draw(ItemRenderer ir, ItemStack stack, ItemDisplayContext ctx, PoseStack ps,
                             MultiBufferSource buf, int light, int overlay, ResourceLocation rl) {
        BakedModel m = Minecraft.getInstance().getModelManager().getModel(rl);
        boolean left = ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                || ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
        ir.render(stack, ctx, left, ps, buf, light, overlay, m);
    }
}
