package com.rustcraft;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Меню верстака без слотов. Кнопки приходят через clickMenuButton:
 * код = действие * 1000 + индекс записи в WeaponTree.ALL.
 * Действия: 0 - изучить, 1 - создать, 2 - улучшить верстак.
 * Синхронизация: 4 слота по 16 бит (маска изученного) + слот уровня верстака.
 */
public class WorkbenchMenu extends AbstractContainerMenu {
    public static final int ACT_RESEARCH = 0;
    public static final int ACT_CRAFT = 1;
    public static final int ACT_UPGRADE = 2;

    private final ContainerData data = new SimpleContainerData(5);
    private final ContainerLevelAccess access;
    private final Player player;

    /** Клиентский конструктор. */
    public WorkbenchMenu(int id, Inventory inv, int tier) {
        this(id, inv, ContainerLevelAccess.NULL, tier);
    }

    public WorkbenchMenu(int id, Inventory inv, ContainerLevelAccess access, int tier) {
        super(ModMenus.WORKBENCH.get(), id);
        this.access = access;
        this.player = inv.player;
        data.set(4, tier);
        addDataSlots(data);
        refresh();
    }

    public static int code(int action, int index) {
        return action * 1000 + index;
    }

    private void refresh() {
        if (player.level().isClientSide) return;
        long bits = Research.bits(player);
        for (int i = 0; i < 4; i++) data.set(i, (int) ((bits >> (16 * i)) & 0xFFFFL));
        int t = serverTier();
        if (t > 0) data.set(4, t);
    }

    private int serverTier() {
        int[] out = {0};
        access.execute((level, pos) -> {
            BlockState s = level.getBlockState(pos);
            if (s.getBlock() instanceof WorkbenchBlock wb) out[0] = wb.tier;
        });
        return out[0];
    }

    @Override
    public void broadcastChanges() {
        refresh();
        super.broadcastChanges();
    }

    public int tier() {
        return data.get(4);
    }

    /** Изучено ли оружие (работает и на клиенте). */
    public boolean isResearched(WeaponTree.Entry e) {
        if (e.bit() < 0) return true;
        int word = data.get(e.bit() / 16) & 0xFFFF;
        return (word & (1 << (e.bit() % 16))) != 0;
    }

    @Override
    public boolean clickMenuButton(Player p, int id) {
        int action = id / 1000;
        int idx = id % 1000;
        int tier = serverTier();
        if (tier <= 0) return false;
        boolean creative = p.getAbilities().instabuild;

        if (action == ACT_UPGRADE) {
            if (tier >= 3) return false;
            int cost = RustBalance.UPGRADE_SCRAP[tier + 1];
            Item scrap = ModItems.SCRAP.get();
            if (!creative && InvUtil.count(p, scrap) < cost) {
                msg(p, "msg.rustcraft.need_scrap");
                return false;
            }
            if (!creative) InvUtil.remove(p, scrap, cost);
            int next = tier + 1;
            access.execute((level, pos) -> level.setBlock(pos, ModBlocks.workbench(next).defaultBlockState(), 3));
            sound(p, true);
            msg(p, "msg.rustcraft.upgraded");
            return true;
        }

        if (idx < 0 || idx >= WeaponTree.ALL.size()) return false;
        WeaponTree.Entry e = WeaponTree.ALL.get(idx);
        if (tier < e.tier()) {
            msg(p, "msg.rustcraft.low_bench");
            return false;
        }

        if (action == ACT_RESEARCH) {
            if (e.kind() != WeaponTree.Kind.WEAPON || Research.has(p, e.id())) return false;
            Item scrap = ModItems.SCRAP.get();
            if (!creative && InvUtil.count(p, scrap) < e.scrap()) {
                msg(p, "msg.rustcraft.need_scrap");
                return false;
            }
            if (!creative) InvUtil.remove(p, scrap, e.scrap());
            Research.add(p, e.id());
            sound(p, true);
            msg(p, "msg.rustcraft.researched");
            return true;
        }

        if (action == ACT_CRAFT) {
            if (e.kind() == WeaponTree.Kind.WEAPON && !Research.has(p, e.id())) {
                msg(p, "msg.rustcraft.not_researched");
                return false;
            }
            if (!creative) {
                for (WeaponTree.Ing ing : e.cost()) {
                    if (InvUtil.count(p, WeaponTree.item(ing.item())) < ing.count()) {
                        msg(p, "msg.rustcraft.need_items");
                        return false;
                    }
                }
                for (WeaponTree.Ing ing : e.cost()) {
                    InvUtil.remove(p, WeaponTree.item(ing.item()), ing.count());
                }
            }
            ItemStack out = WeaponTree.stack(e);
            if (!p.getInventory().add(out)) p.drop(out, false);
            sound(p, false);
            return true;
        }
        return false;
    }

    private static void msg(Player p, String key) {
        p.displayClientMessage(Component.translatable(key), true);
    }

    private static void sound(Player p, boolean big) {
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(),
                big ? SoundEvents.ENCHANTMENT_TABLE_USE : SoundEvents.ANVIL_USE,
                SoundSource.BLOCKS, big ? 0.8F : 0.4F, big ? 1.0F : 1.4F);
    }

    @Override
    public ItemStack quickMoveStack(Player p, int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player p) {
        return access.evaluate((level, pos) -> level.getBlockState(pos).getBlock() instanceof WorkbenchBlock
                && p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0, true);
    }
}
