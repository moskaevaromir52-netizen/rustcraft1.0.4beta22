package com.rustcraft;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

/** Изученные чертежи игрока (хранятся в данных игрока, переживают смерть). */
public final class Research {
    public static final String KEY = "rust_research";

    private Research() {
    }

    public static boolean has(Player p, String id) {
        ListTag l = p.getPersistentData().getList(KEY, Tag.TAG_STRING);
        for (int i = 0; i < l.size(); i++) if (l.getString(i).equals(id)) return true;
        return false;
    }

    public static void add(Player p, String id) {
        if (has(p, id)) return;
        CompoundTag d = p.getPersistentData();
        ListTag l = d.getList(KEY, Tag.TAG_STRING);
        l.add(StringTag.valueOf(id));
        d.put(KEY, l);
    }

    /** Битовая маска изученного по WeaponTree.bit. */
    public static long bits(Player p) {
        long b = 0;
        for (WeaponTree.Entry e : WeaponTree.ALL) {
            if (e.bit() >= 0 && has(p, e.id())) b |= 1L << e.bit();
        }
        return b;
    }
}
