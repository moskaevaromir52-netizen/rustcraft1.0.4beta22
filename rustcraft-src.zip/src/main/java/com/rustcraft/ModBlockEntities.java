package com.rustcraft;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, RustCraft.MODID);

    public static final RegistryObject<BlockEntityType<CrateBlockEntity>> CRATE = TYPES.register("crate",
            () -> BlockEntityType.Builder.of(CrateBlockEntity::new,
                    ModBlocks.CRATES.stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    private ModBlockEntities() {
    }
}
