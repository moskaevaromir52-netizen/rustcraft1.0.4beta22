package com.rustcraft;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Анимация отдачи оружия в руке (от первого лица): ствол подбрасывает вверх и немного
 * в сторону, оружие откатывается к игроку и возвращается. Заодно убирает «проседание»
 * оружия, которое ваниль делает при каждом повторном использовании предмета.
 */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GunAnimClient {
    private static float kick;
    private static float prevKick;
    private static float side;
    private static float scale = 1.0F;
    // положение оружия «от бедра» (подобрано симуляцией вида от первого лица)
    private static final float HIP_DX = 0.20F;
    private static final float HIP_DY = 0.20F;
    private static final float HIP_DZ = -0.10F;
    private static final float HIP_YAW = 14.0F;
    private static final float HIP_PITCH = 6.0F;
    private static float aim;
    private static float prevAim;

    private static boolean modified = false;
    private static final Matrix4f savedPose = new Matrix4f();
    private static final Matrix3f savedNormal = new Matrix3f();

    private GunAnimClient() {
    }

    static void shot(float recoil) {
        kick = Math.min(1.6F, kick + 1.0F);
        scale = Mth.clamp(recoil, 0.5F, 6.0F);
        Minecraft mc = Minecraft.getInstance();
        side = mc.player == null ? 0 : (mc.player.getRandom().nextFloat() - 0.5F) * 2.0F;
    }

    /** Плавный прогресс прицеливания 0..1. */
    static float aim() {
        return aim;
    }

    private static float sightExtra(net.minecraft.world.item.ItemStack st) {
        Attachment a = Attachments.get(st, Attachment.Slot.SIGHT);
        if (a == null) return 1.0F;
        return switch (a.id) {
            case "holosight" -> 2.0F;
            case "scope_8x" -> 2.4F;
            case "variable_scope" -> 2.5F;
            default -> 1.5F;
        };
    }

    static void tick() {
        prevAim = aim;
        aim = Mth.clamp(aim + (AimState.aiming() ? 0.34F : -0.34F), 0.0F, 1.0F);
        prevKick = kick;
        kick *= 0.58F;
        if (kick < 0.01F) kick = 0;
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        PoseStack ps = e.getPoseStack();
        // всё, что мы изменили у главной руки, возвращаем перед отрисовкой второй
        if (e.getHand() == InteractionHand.OFF_HAND) {
            if (modified) {
                ps.last().pose().set(savedPose);
                ps.last().normal().set(savedNormal);
                modified = false;
            }
            return;
        }
        if (!(e.getItemStack().getItem() instanceof GunItem)) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        // через сильный оптический прицел оружие в руках не рисуем
        if (aim > 0.6F && Attachments.mods(e.getItemStack()).zoom() <= 0.3F) {
            e.setCanceled(true);
            return;
        }

        savedPose.set(ps.last().pose());
        savedNormal.set(ps.last().normal());
        modified = true;

        // ванильное проседание при повторном use() - компенсируем
        if (p.isUsingItem()) {
            ps.translate(0.0F, 0.6F * e.getEquipProgress(), 0.0F);
        }

        float sx = p.getMainArm() == HumanoidArm.RIGHT ? 1.0F : -1.0F;
        float ap = Mth.lerp(e.getPartialTick(), prevAim, aim);
        ap = ap * ap * (3.0F - 2.0F * ap);
        float hip = 1.0F - ap;

        // «Бедренная» поза: оружие слева-внизу, довёрнуто к центру (плавно уходит при прицеливании)
        ps.translate(-HIP_DX * sx * hip, HIP_DY * hip, HIP_DZ * hip);
        ps.translate(0.56F * sx, -0.52F, -0.72F);
        ps.mulPose(Axis.YP.rotationDegrees(HIP_YAW * sx * hip));
        ps.mulPose(Axis.XP.rotationDegrees(HIP_PITCH * hip));
        ps.translate(-0.56F * sx, 0.52F, 0.72F);

        // Прицеливание: прицельная линия оружия - в центр экрана
        if (ap > 0.0F) {
            float[] sp = GunSights.get(Attachments.gunId(e.getItemStack().getItem()));
            float dy = 0.52F - (sp[0] + sightExtra(e.getItemStack())) * sp[1] / 16.0F;
            ps.translate(-0.56F * sx * ap, dy * ap, 0.0F);
        }

        float k = Mth.lerp(e.getPartialTick(), prevKick, kick) * (1.0F - 0.5F * ap);
        if (k <= 0.0F) return;
        float back = k * (0.03F + 0.012F * scale);
        float pitch = k * Math.min(14.0F, 1.8F + 2.0F * scale);
        float yaw = k * side * (0.6F + 0.3F * scale);

        ps.translate(0.0F, 0.0F, back);
        ps.translate(0.56F * sx, -0.45F, -0.7F);
        ps.mulPose(Axis.XP.rotationDegrees(pitch));
        ps.mulPose(Axis.YP.rotationDegrees(yaw));
        ps.translate(-0.56F * sx, 0.45F, 0.7F);
    }
}
