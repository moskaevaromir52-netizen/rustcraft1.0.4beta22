package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.Container;

/** Ящик с лутом (как в Rust): открывается по ПКМ, лут генерируется при первом открытии, пустой исчезает и возрождается. */
public class CrateBlock extends BaseEntityBlock {
    public enum Type {
        NORMAL("normal_crate", 2, 18000),
        FOOD("food_crate", 2, 18000),
        MEDICAL("medical_crate", 2, 21000),
        TOOLS("tool_box", 2, 18000),
        MILITARY("military_crate", 3, 30000),
        ELITE("elite_crate", 3, 48000);

        public final String id;
        public final int rows;
        /** Через сколько тиков ящик появится снова после опустошения. */
        public final int respawn;

        Type(String id, int rows, int respawn) {
            this.id = id;
            this.rows = rows;
            this.respawn = respawn;
        }

        public ResourceLocation lootTable() {
            return new ResourceLocation(RustCraft.MODID, "crates/" + id);
        }
    }

    private static final VoxelShape SHAPE = net.minecraft.world.level.block.Block.box(1, 0, 1, 15, 13, 15);

    public final Type type;

    public CrateBlock(Properties props, Type type) {
        super(props);
        this.type = type;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public net.minecraft.world.level.block.entity.BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CrateBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof CrateBlockEntity crate) {
            level.playSound(null, pos, SoundEvents.BARREL_OPEN, SoundSource.BLOCKS, 0.8F, 1.1F);
            player.openMenu(crate);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof Container c) {
                Containers.dropContents(level, pos, c);
                level.updateNeighbourForOutputSignal(pos, this);
            }
            super.onRemove(state, level, pos, newState, moving);
        }
    }
}
