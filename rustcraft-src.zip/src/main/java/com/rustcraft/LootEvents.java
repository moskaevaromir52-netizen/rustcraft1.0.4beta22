package com.rustcraft;

import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LootEvents {
    private LootEvents() {
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel sl)) return;
        if (sl.getGameTime() % 100 != 0) return;
        LootRespawn.get(sl).tick(sl);
    }
}
