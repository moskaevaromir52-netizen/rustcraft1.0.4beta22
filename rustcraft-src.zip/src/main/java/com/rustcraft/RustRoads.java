package com.rustcraft;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.LegacyRandomSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Дорожная сеть, как в Rust: дороги между деревнями, от них ответвления к свалке и военному посту,
 * у дорог редко стоят склад, заправка и супермаркет, на обочинах - обычные ящики.
 * Всё вычисляется детерминированно из сида мира, поэтому каждый чанк сам знает свою часть.
 * Деревни берутся из той же формулы, что и у ванильных (spacing 34, separation 8).
 */
public final class RustRoads {
    public static final int SPACING = 34;
    private static final int SEPARATION = 8;
    private static final int SALT = 10387312;
    public static final double ROAD_RADIUS = 2.3;

    private RustRoads() {
    }

    // ------------------------------------------------------------------ типы
    public record Road(int ax, int az, int bx, int bz, double bend, long id, boolean spur, double tEnd) {
        public double len() {
            return Math.hypot(bx - ax, bz - az);
        }

        public double nx() {
            double l = Math.max(1.0, len());
            return -(bz - az) / l;
        }

        public double nz() {
            double l = Math.max(1.0, len());
            return (bx - ax) / l;
        }

        public double x(double t) {
            return ax + (bx - ax) * t + nx() * bend * Math.sin(Math.PI * t);
        }

        public double z(double t) {
            return az + (bz - az) * t + nz() * bend * Math.sin(Math.PI * t);
        }
    }

    /** Монумент у дороги: центр - центр чанка; fx,fz - куда «смотрит» вход (в сторону дороги). */
    public record Mon(int x, int z, String type, double fx, double fz) {
    }

    public record Crate(int x, int z) {
    }

    private static final class Extras {
        Road spur;
        final List<Mon> mons = new ArrayList<>();
        final List<Crate> crates = new ArrayList<>();
    }

    // ------------------------------------------------------------------ вспомогательное
    private static Random rng(long seed, long a, long b, long c) {
        long h = seed * 0x9E3779B97F4A7C15L ^ a * 0xC2B2AE3D27D4EB4FL ^ b * 0x165667B19E3779F9L ^ c * 0x27D4EB2F165667C5L;
        h ^= h >>> 29;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 32;
        return new Random(h);
    }

    private static int snap(double v) {
        return Math.floorDiv((int) Math.floor(v), 16) * 16 + 8;
    }

    // ------------------------------------------------------------------ деревни
    private static final Map<String, Optional<int[]>> SITES = new ConcurrentHashMap<>();
    private static final Map<Long, Extras> EXTRAS = new ConcurrentHashMap<>();

    private static Optional<int[]> site(ServerLevel sl, long seed, int rx, int rz) {
        String key = seed + ":" + rx + ":" + rz;
        Optional<int[]> cached = SITES.get(key);
        if (cached != null) return cached;
        Optional<int[]> r = computeSite(sl, seed, rx, rz);
        SITES.put(key, r);
        return r;
    }

    private static Optional<int[]> computeSite(ServerLevel sl, long seed, int rx, int rz) {
        WorldgenRandom r = new WorldgenRandom(new LegacyRandomSource(0L));
        r.setLargeFeatureWithSalt(seed, rx, rz, SALT);
        int bound = SPACING - SEPARATION;
        int dx = r.nextInt(bound);
        int dz = r.nextInt(bound);
        ChunkPos c = new ChunkPos(rx * SPACING + dx, rz * SPACING + dz);
        int x = c.x * 16 + 8;
        int z = c.z * 16 + 8;
        try {
            Climate.Sampler sampler = sl.getChunkSource().randomState().sampler();
            Holder<Biome> b = sl.getChunkSource().getGenerator().getBiomeSource().getNoiseBiome(x >> 2, 16, z >> 2, sampler);
            boolean ok = b.is(BiomeTags.HAS_VILLAGE_PLAINS) || b.is(BiomeTags.HAS_VILLAGE_DESERT)
                    || b.is(BiomeTags.HAS_VILLAGE_SAVANNA) || b.is(BiomeTags.HAS_VILLAGE_SNOWY)
                    || b.is(BiomeTags.HAS_VILLAGE_TAIGA);
            return ok ? Optional.of(new int[]{x, z}) : Optional.empty();
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    // ------------------------------------------------------------------ дороги
    private static List<Road> mainRoads(ServerLevel sl, long seed, int rx0, int rz0) {
        List<Road> out = new ArrayList<>();
        for (int rx = rx0 - 2; rx <= rx0 + 2; rx++) {
            for (int rz = rz0 - 2; rz <= rz0 + 2; rz++) {
                Optional<int[]> a = site(sl, seed, rx, rz);
                if (a.isEmpty()) continue;
                for (int d = 1; d <= 2; d++) {
                    Optional<int[]> b = site(sl, seed, rx + d, rz);
                    if (b.isPresent()) {
                        out.add(makeRoad(seed, a.get(), b.get(), false, 0.3));
                        break;
                    }
                }
                for (int d = 1; d <= 2; d++) {
                    Optional<int[]> b = site(sl, seed, rx, rz + d);
                    if (b.isPresent()) {
                        out.add(makeRoad(seed, a.get(), b.get(), false, 0.3));
                        break;
                    }
                }
            }
        }
        return out;
    }

    private static Road makeRoad(long seed, int[] a, int[] b, boolean spur, double bendFactor) {
        long id = rng(seed, a[0], a[1], (long) b[0] * 31 + b[1]).nextLong();
        Random r = rng(seed, id, 7, 7);
        double len = Math.hypot(b[0] - a[0], b[1] - a[1]);
        double bend = (r.nextDouble() - 0.5) * bendFactor * len * 0.5;
        double tEnd = spur ? Math.max(0.2, 1.0 - 10.0 / Math.max(1.0, len)) : 1.0;
        return new Road(a[0], a[1], b[0], b[1], bend, id, spur, tEnd);
    }

    private static Extras extras(long seed, Road main) {
        Extras cached = EXTRAS.get(main.id());
        if (cached != null) return cached;
        Extras e = new Extras();
        double len = main.len();
        Random r = rng(seed, main.id(), 99, 1);

        // ответвление к свалке или военному посту
        if (len > 200 && r.nextFloat() < 0.55F) {
            double t = 0.2 + 0.6 * r.nextDouble();
            int side = r.nextBoolean() ? 1 : -1;
            double dist = 75 + r.nextInt(60);
            double px = main.x(t);
            double pz = main.z(t);
            int sx = snap(px + main.nx() * side * dist);
            int sz = snap(pz + main.nz() * side * dist);
            e.spur = makeRoad(seed, new int[]{(int) Math.round(px), (int) Math.round(pz)}, new int[]{sx, sz}, true, 0.2);
            e.mons.add(new Mon(sx, sz, r.nextFloat() < 0.6F ? "junkyard" : "military_outpost",
                    px - sx, pz - sz));
        }

        // редкие постройки у дороги: склад, заправка, супермаркет
        for (int k = 0; ; k++) {
            double s = 60 + k * 75 + r.nextInt(30);
            if (s > len - 60) break;
            Random rr = rng(seed, main.id(), 200 + k, 3);
            if (rr.nextFloat() < 0.12F) {
                double t = s / len;
                int side = rr.nextBoolean() ? 1 : -1;
                double off = 22 + rr.nextInt(9);
                double px = main.x(t);
                double pz = main.z(t);
                int mx = snap(px + main.nx() * side * off);
                int mz = snap(pz + main.nz() * side * off);
                float pick = rr.nextFloat();
                String type = pick < 0.40F ? "warehouse" : (pick < 0.75F ? "gas_station" : "supermarket");
                e.mons.add(new Mon(mx, mz, type, px - mx, pz - mz));
            }
        }
        addCrates(seed, main, e);
        if (e.spur != null) addCrates(seed, e.spur, e);
        EXTRAS.put(main.id(), e);
        return e;
    }

    /** Обычные ящики на обочине, не часто. */
    private static void addCrates(long seed, Road road, Extras e) {
        double len = road.len();
        double end = len * road.tEnd();
        for (int k = 0; ; k++) {
            double s = 24 + k * 24;
            if (s > end - 16) break;
            Random rr = rng(seed, road.id(), 1000 + k, 5);
            if (rr.nextFloat() < 0.35F) {
                double t = s / len;
                int side = rr.nextBoolean() ? 1 : -1;
                double off = ROAD_RADIUS + 1.4;
                e.crates.add(new Crate((int) Math.floor(road.x(t) + road.nx() * side * off),
                        (int) Math.floor(road.z(t) + road.nz() * side * off)));
            }
        }
    }

    // ------------------------------------------------------------------ план чанка
    public static final class Plan {
        public final List<Road> paint = new ArrayList<>();
        public final List<Mon> monuments = new ArrayList<>();
        public final List<Crate> crates = new ArrayList<>();
    }

    private static boolean near(Road r, int x0, int z0, int margin) {
        double len = r.len();
        int n = (int) Math.ceil(len * r.tEnd() / 6.0);
        for (int i = 0; i <= n; i++) {
            double t = Math.min(r.tEnd(), (i * 6.0) / len);
            double x = r.x(t);
            double z = r.z(t);
            if (x >= x0 - margin && x <= x0 + 15 + margin && z >= z0 - margin && z <= z0 + 15 + margin) return true;
        }
        return false;
    }

    public static Plan plan(ServerLevel sl, long seed, int chunkX, int chunkZ) {
        Plan plan = new Plan();
        int x0 = chunkX * 16;
        int z0 = chunkZ * 16;
        int rx0 = Math.floorDiv(chunkX, SPACING);
        int rz0 = Math.floorDiv(chunkZ, SPACING);
        for (Road main : mainRoads(sl, seed, rx0, rz0)) {
            Extras ex = extras(seed, main);
            if (near(main, x0, z0, 8)) plan.paint.add(main);
            if (ex.spur != null && near(ex.spur, x0, z0, 8)) plan.paint.add(ex.spur);
            for (Mon m : ex.mons) {
                if (Math.floorDiv(m.x(), 16) == chunkX && Math.floorDiv(m.z(), 16) == chunkZ) plan.monuments.add(m);
            }
            for (Crate c : ex.crates) {
                if (c.x() >= x0 && c.x() <= x0 + 15 && c.z() >= z0 && c.z() <= z0 + 15) plan.crates.add(c);
            }
        }
        return plan;
    }
}
