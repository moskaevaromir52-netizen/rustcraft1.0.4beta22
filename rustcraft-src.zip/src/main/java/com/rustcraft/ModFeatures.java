package com.rustcraft;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, RustCraft.MODID);

    public static final RegistryObject<Feature<MonumentFeature.Config>> MONUMENT =
            FEATURES.register("monument", MonumentFeature::new);

    public static final RegistryObject<Feature<net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration>> ROADS =
            FEATURES.register("roads", RoadFeature::new);

    private ModFeatures() {
    }
}
