package com.rustcraft;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Клавиши мода (только клиент). */
public final class ClientKeys {
    public static final String CATEGORY = "key.categories.rustcraft";
    public static final KeyMapping ATTACH = new KeyMapping("key.rustcraft.attachments",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, CATEGORY);
    public static final KeyMapping TOGGLE = new KeyMapping("key.rustcraft.toggle_mod",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY);

    private ClientKeys() {
    }
}
